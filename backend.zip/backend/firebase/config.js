// import admin from "firebase-admin";
// import { createRequire } from "module";

// const require = createRequire(
//     import.meta.url);
// const serviceAccount = require("./serviceAccountKey.json");

// if (!admin.apps.length) {
//     admin.initializeApp({
//         credential: admin.credential.cert(serviceAccount),
//     });
// }

// export const db = admin.firestore();
// export const auth = admin.auth();
// export default admin;import admin from "firebase-admin";

import admin from "firebase-admin";
import dotenv from "dotenv";
dotenv.config();

if (!admin.apps.length) {
    admin.initializeApp({
        credential: admin.credential.cert({
            projectId: process.env.FIREBASE_PROJECT_ID,
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
            privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, "\n"),
        }),
    });
}

export const db = admin.firestore();
export const auth = admin.auth();
export default admin;